let salon={
    name:"The Pampered Pooch",
    address:{
        street:"Clifford Street",
        ZIPcode:"37175",
        number:"867-5309"
    },
    hours:{
        open:"9:00 am",
        close:"5:00 pm"
    }
,
pets: []
}


function displayPetNames(){
  alert(`You have ${salon.pets.length}pets.`);
        for(let i=0;i<salon.pets.length;i++){
            console.log(salon.pets[i]);
        }
    }
//create the constructor
function Pet(name,age,gender,breed,service,owner,contact){
    this.name=name;
    this.age=age;
    this.gender=gender;
    this.breed=breed;
    this.service=service;
    this.owner=owner;
    this.contact=contact;

}

//create three pets using the constructor
let cujo= new Pet("Cujo", 43,"male","bernard","washing","Bob","555-5555");
let skip=new Pet("Skip", 23,"male","wiener-dog","grooming","Jerry","555-4343");
let garbanzo=new Pet("Garbanzo", 12,"female","rottweiler","washing","Fredo","555-9683")
let triumph=new Pet("Triumph", 37,"male","doberman","nail clipping","George","555-3956")
salon.pets.push();//push the element into the array


let petName = document.getElementById("txtName");
let petAge = document.getElementById("txtAge");
let petGender = document.getElementById("selGender");
let petBreed = document.getElementById("txtBreed");
let petService = document.getElementById("selService");
let petOwner = document.getElementById("txtOwner");
let petContact = document.getElementById("txtContact");


function register(){
     console.log("register"); 
     //create an obj
     let thePet=new Pet(petName.value,petAge.value,petGender.value,petBreed.value,petService.value,petOwner.value,petContact.value);
     console.log(thePet);
     //push the objec into the array
     salon.pets.push(thePet);
     //display the array
    console.log(salon.pets);       
    //alert
    showPetCards();
    alert("Thank you for registering!");
}


function showPetCards(){
    document.getElementById('btnClear').hidden = true;

    document.getElementById('headerList').innerHTML="Pet List"
    //clear the field
    document.getElementById("petList").innerHTML="";
    //travel the array(loop)
    for(let i=0;i<salon.pets.length;i++){
        //create the card and append the tmp into the html
        document.getElementById("petList").innerHTML +=createCard(salon.pets[i], i);
    }
}
function removePet(index){
    if(index < salon.pets.length)
        {
    salon.pets.splice(index, 1);
        }
        showPetCards();
}

function searchPet(){
    document.getElementById('btnClear').hidden = false;
    let name=document.getElementById('txtSearch').value;
    document.getElementById("headerList").innerHTML = "Search Result";
    //clear the field
    document.getElementById("petList").innerHTML="";
    //travel the array(loop)
    for(let i=0;i<salon.pets.length;i++){
        //create the card and append the tmp into the html
        if(name.toLowerCase() == salon.pets[i].name.toLowerCase())
        {
        document.getElementById("petList").innerHTML +=createCard(salon.pets[i], i);
        }
    }
}

function createCard(pet, index){
    return `
    <div class="pet-card">
    <h3>${pet.name}</h3>
    <p>Age: ${pet.age}</p>
    <p>Gender: ${pet.gender}</p>
    <p>Service: ${pet.service}</p>
    <p>Owner: ${pet.owner}</p>
    <p>Contact: ${pet.contact}</p>
    <button onclick="removePet(${index});" >Remove</button>
    </div>
    `;
    //display the rest of the properties
}

function init(){
    //create three pets using the constructor
let cujo= new Pet("cujo", 43,"male","bernard","grooming");
let skip=new Pet("skip", 23,"male","lab","Nail Clipping");
let garbanzo=new Pet("garbanzo", 12,"female","lab","Grooming");
let triumph=new Pet("triumph", 37,"male","lab","grooming");
}
salon.pets.push(cujo,skip,garbanzo,triumph);//push the element into the array
showPetCards();
window.onload=init;