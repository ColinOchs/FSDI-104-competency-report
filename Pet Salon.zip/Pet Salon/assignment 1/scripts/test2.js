//object literal
let monkey={
    name:"Bonzo",
    planetOf:true,
    food:"banana"
}
let monkey2={
    name:"Kong",
    planetOf:false,
    food:"humans"
}

//object constructor
function Animal(name,planetOf,food){
    this.name=name;
    this.planetOf=planetOf;
    this.food=food;
    this.hunger=10;
    this.feed=function(){
        console.log("feeding the pet");
        this.hunger=this.hunger-2;
        return "hello";
    }
}
//create objects
let monkeyB = new Animal("Bonzo",true,"banana");
console.log(monkeyB.feed());

//create a constructor
//school,student,instructors,assignment,courses, exam,
let course1={
    name:"math",
    grade:"C"}
let course2={
    name:"science",
    grade:"B"}
let course3={
    name:"art",
    grade:"A"}

function Courses(course1,course2,course3){
    this.course1=course1;
    this.course2=course2;
    this.course3=course3;
}
let courseList= new Courses(course1,course2,course3);
console.log(courseList);